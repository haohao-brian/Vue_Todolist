#include <fstream> // Required for file stream operations
#include <iostream> // Required for input/output operations
#include <thread>         // std::thread
#include <exception>
using namespace std;
bool a_left(char input[16][16],int x, int y, char me){
	if (x-1 < 0){
		return FALSE;
	}
	bool res = FALSE;
	switch (input[x-1][y]){
		case '.':res = TRUE;
			break;
		case '#':res = FALSE;
			break;
		case 'x':
			res = (me=='o'||me=='O'||me=='Q')?TRUE:FALSE;
			break;
		case 'X':res = (me=='o'||me=='O'||me=='Q')?TRUE:FALSE;
			break;
		case ' ':res = TRUE;
			break;
		case '@':res = (me=='o'||me=='O'||me=='Q')?TRUE:FALSE;
			break;
		case '!':res = FALSE; // never happens
			break;
		default:
			res = FALSE;
			break;
	}
	

}
int main() {
    // Open the file for reading
    char str[16][16];
    ifstream inputFile("samples/01.txt"); 

    // Check if the file was opened successfully
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file." << endl;
        return 1; // Indicate an error
    }

    char ch; // Variable to store the character read

    // Read characters one by one until the end of the file is reached
    int x = 0, y = 0;
    int z1,z2;
    while (inputFile.get(ch)) {
        // Process the character (e.g., print it to the console)
        cout << ch;
	if (ch == '\n'){
		x = 0;
	     y++;
	}else {
	     str[x][y] = ch;
	     if (str[x][y]=='o'){
		 z1 = x;
		z2 = y;
	     }
	     x++;
	}
    }
    cout << y << " " << z1 << " " << z2 << endl;
    // Check if any error occurred during reading (excluding end-of-file)
    if (inputFile.bad()) {
        cerr << "Error: An I/O error occurred while reading." << endl;
    }
	char a = str[1][17];
	cout << a << endl;
    try {
	char a = str[-1][17];
    } catch (std::exception &e) { // exception should be caught by reference
        cout << "exception: " << e.what() << "\n";
    }
    // Close the file
    inputFile.close(); 

    return 0; // Indicate successful execution
}
