// mini_miner_80_target.cu
// 80-byte block header + double SHA-256 + 256-bit big-endian target compare
// 每個 thread 試一個 nonce，找出第一個 hash <= target 的 nonce

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <cuda_runtime.h>

typedef uint8_t  BYTE;
typedef uint32_t WORD;


// This sha256 implementation is based on sha256 wiki page
// please refer to:
//     https://en.wikipedia.org/wiki/SHA-2
void getline_hw(char *str, size_t len, FILE *fp)
{
    int i = 0;
    while ( i < (int)len && (str[i] = fgetc(fp)) != EOF && str[i++] != '\n');
    str[len-1] = '\0';
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sha256.h"

// circular shift - wiki:
//     https://en.wikipedia.org/wiki/Circular_shift
#define _rotl(v, s) ((v)<<(s) | (v)>>(32-(s)))
#define _rotr(v, s) ((v)>>(s) | (v)<<(32-(s)))

#define _swap(x, y) (((x)^=(y)), ((y)^=(x)), ((x)^=(y)))

#ifdef __cplusplus
extern "C"{
#endif  //__cplusplus

static const WORD k[64] = {
	0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
	0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
	0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
	0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
	0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
	0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
	0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
	0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};



// Unit test
#ifdef __SHA256_UNITTEST__
	#define print_hash(x) printf("sha256 hash: "); for(int i=0;i<32;++i)printf("%02X", (x).b[i]);
	#define print_msg(x) printf("%s", ((x) ? "Pass":"Failed"))

int main(int argc, char **argv)
{
	SHA256 ctx;
	
	// ------------------ Stage 1: abc
	printf("------- Stage 1 : abc -------\n");
	BYTE abc[] = "abc";
	BYTE abcans[] = {0xBA, 0x78, 0x16, 0xBF, 0x8F, 0x01, 0xCF, 0xEA, 
					 0x41, 0x41, 0x40, 0xDE, 0x5D, 0xAE, 0x22, 0x23, 
					 0xB0, 0x03, 0x61, 0xA3, 0x96, 0x17, 0x7A, 0x9C, 
					 0xB4, 0x10, 0xFF, 0x61, 0xF2, 0x00, 0x15, 0xAD};
	size_t abclen = sizeof(abc) - 1;
	sha256(&ctx, abc, abclen);
	print_hash(ctx);
	printf("\nResult: ");
	print_msg(!memcmp(abcans, ctx.b, 32));
	printf("\n\n");
	
	// ------------------ Stage 2: len55
	printf("------ Stage 2 : len55 ------\n");
	BYTE len55[] = "1234567890123456789012345678901234567890123456789012345";
	BYTE len55ans[] = {0x03, 0xC3, 0xA7, 0x0E, 0x99, 0xED, 0x5E, 0xEC, 
					   0xCD, 0x80, 0xF7, 0x37, 0x71, 0xFC, 0xF1, 0xEC, 
					   0xE6, 0x43, 0xD9, 0x39, 0xD9, 0xEC, 0xC7, 0x6F, 
					   0x25, 0x54, 0x4B, 0x02, 0x33, 0xF7, 0x08, 0xE9};
	size_t len55len = sizeof(len55) - 1;
	sha256(&ctx, len55, len55len);
	print_hash(ctx);
	printf("\nResult: ");
	print_msg(!memcmp(len55ans, ctx.b, 32));
	printf("\n\n");
	
	// ------------------ Stage 3: len290
	printf("----- Stage 3 : len290 ------\n");
	BYTE len290[] = "ads;flkjas;dlkfjads;flkjads;flkafdlkjhfdalkjgadslfkjhadsjhfveroi"
					"uhwerpiuhwerptoiuywerptoiuywterypoihslgkjhdxzflgknbzsfdlkgjhsdfp"
					"gikjhwepgoiuhywertpiuywerptiuywrtoiuhwserlkjhsfdlgkjbsfd,nkmbxcv"
					".bkmnxflkjbnfdslgkjhsgpoiuhserpiuywerpituywetrpoiuhywerlkjbsfd,g"
					"nkbxsflkdjbsdflkjhsgfdluhsdgliuher";
	BYTE len290ans[] = {0xBD, 0xB5, 0xD4, 0xC1, 0xFB, 0x45, 0x1A, 0xD2, 
						0xFC, 0x8E, 0x62, 0x26, 0xF9, 0x5C, 0x6B, 0x58, 
						0x31, 0x53, 0x90, 0x1B, 0xE3, 0x74, 0xC2, 0x60, 
						0xC8, 0xA7, 0x46, 0x09, 0xC6, 0x89, 0x24, 0x60};
	size_t len290len = sizeof(len290) - 1;
	sha256(&ctx, len290, len290len);
	print_hash(ctx);
	printf("\nResult: ");
	print_msg(!memcmp(len290ans, ctx.b, 32));
	printf("\n\n");
	
	return 0;
}
#endif  //__SHA256_UNITTEST__

#ifdef __cplusplus
}
#endif  //__cplusplus

#undef _rotl
#undef _rotr

// Compare two 256-bit numbers as LITTLE-ENDIAN byte arrays.
// Same logic as CPU little_endian_bit_comparison(...)
__device__ int cmp256_le(const BYTE a[32], const BYTE b[32]) {
    for (int i = 31; i >= 0; --i) {
        BYTE x = a[i];
        BYTE y = b[i];
        if (x < y) return -1;
        if (x > y) return 1;
    }
    return 0;
}
void print_hex(unsigned char* hex, size_t len)
{
    for(int i=0;i<len;++i)
    {
        printf("%02x", hex[i]);
    }
}


// print out binar array (from lowest value) in the hex format
void print_hex_inverse(unsigned char* hex, size_t len)
{
    for(int i=len-1;i>=0;--i)
    {
        printf("%02x", hex[i]);
    }
}

unsigned char decode(unsigned char c)
{
    switch(c)
    {
     	case 'a':
            return 0x0a;
        case 'b':
            return 0x0b;
        case 'c':
            return 0x0c;
        case 'd':
            return 0x0d;
        case 'e':
            return 0x0e;
        case 'f':
            return 0x0f;
        case '0' ... '9':
            return c-'0';
    }
}
void convert_string_to_little_endian_bytes(unsigned char* out, char *in, size_t string_len)
{
 //   assert(string_len % 2 == 0);

    size_t s = 0;
    size_t b = string_len/2-1;

    for(s, b; s < string_len; s+=2, --b)
    {
        out[b] = (unsigned char)(decode(in[s])<<4) + decode(in[s+1]);
    }
}
/*
void calc_merkle_root(unsigned char *root, int count, char **branch)
{
    size_t total_count = count; // merkle branch
    unsigned char *raw_list = new unsigned char[(total_count+1)*32];
    unsigned char **list = new unsigned char*[total_count+1];

    // copy each branch to the list
    for(int i=0;i<total_count; ++i)
    {
        list[i] = raw_list + i * 32;
        //convert hex string to bytes array and store them into the list
        convert_string_to_little_endian_bytes(list[i], branch[i], 64);
    }

    list[total_count] = raw_list + total_count*32;


    // calculate merkle root
    while(total_count > 1)
    {
        
        // hash each pair
        int i, j;

        if(total_count % 2 == 1)  //odd, 
        {
            memcpy(list[total_count], list[total_count-1], 32);
        }

        for(i=0, j=0;i<total_count;i+=2, ++j)
        {
            // this part is slightly tricky,
            //   because of the implementation of the double_sha256,
            //   we can avoid the memory begin overwritten during our sha256d calculation
            // double_sha:
            //     tmp = hash(list[0]+list[1])
            //     list[0] = hash(tmp)
            double_sha256((SHA256*)list[j], list[i], 64);
        }

        total_count = j;
    }

    memcpy(root, list[0], 32);

    delete[] raw_list;
    delete[] list;
}
*/

// ========================= SHA-256 core =========================

// SHA-256 constants in device constant memory
__device__ __constant__ WORD K[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

__device__ __forceinline__ WORD rotr(WORD x, WORD n) {
    return (x >> n) | (x << (32 - n));
}

// process one 512-bit block (64 bytes) into H[8]
__device__ void sha256_process_block(WORD H[8], const BYTE* block) {
    WORD w[64];

    // w[0..15] from block (big-endian)
    for (int i = 0; i < 16; ++i) {
        int j = i * 4;
        w[i] = ((WORD)block[j]   << 24) |
               ((WORD)block[j+1] << 16) |
               ((WORD)block[j+2] <<  8) |
               ((WORD)block[j+3]);
    }

    // w[16..63]
    for (int i = 16; i < 64; ++i) {
        WORD x = w[i-15];
        WORD y = w[i-2];
        WORD s0 = rotr(x, 7) ^ rotr(x, 18) ^ (x >> 3);
        WORD s1 = rotr(y, 17) ^ rotr(y, 19) ^ (y >> 10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }

    WORD a = H[0];
    WORD b = H[1];
    WORD c = H[2];
    WORD d = H[3];
    WORD e = H[4];
    WORD f = H[5];
    WORD g = H[6];
    WORD h = H[7];

    for (int i = 0; i < 64; ++i) {
        WORD S0  = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        WORD S1  = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        WORD ch  = (e & f) ^ ((~e) & g);
        WORD maj = (a & b) ^ (a & c) ^ (b & c);
        WORD t1  = h + S1 + ch + K[i] + w[i];
        WORD t2  = S0 + maj;

        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }

    H[0] += a;
    H[1] += b;
    H[2] += c;
    H[3] += d;
    H[4] += e;
    H[5] += f;
    H[6] += g;
    H[7] += h;
}

// generic SHA-256: handles any length (80 bytes OK)
__device__ void sha256_any(const BYTE* msg, size_t len, BYTE out[32]) {
    // init H
    WORD H[8] = {
        0x6a09e667,
        0xbb67ae85,
        0x3c6ef372,
        0xa54ff53a,
        0x510e527f,
        0x9b05688c,
        0x1f83d9ab,
        0x5be0cd19
    };

    // process full 64-byte chunks
    size_t full = (len / 64) * 64;
    for (size_t offset = 0; offset < full; offset += 64) {
        sha256_process_block(H, msg + offset);
    }

    // padding
    BYTE buf[64];
    size_t rem = len - full;

    // copy remaining bytes
    for (size_t i = 0; i < rem; ++i) {
        buf[i] = msg[full + i];
    }

    // append 0x80
    buf[rem++] = 0x80;

    // if not enough space for 8-byte length, pad this block and start a new one
    if (rem > 56) {
        for (size_t i = rem; i < 64; ++i) {
            buf[i] = 0;
        }
        sha256_process_block(H, buf);
        rem = 0;
    }

    // pad with zeros up to byte 56
    for (size_t i = rem; i < 56; ++i) {
        buf[i] = 0;
    }

    // append 64-bit big-endian length (in bits)
    unsigned long long bitlen = (unsigned long long)len * 8ULL;
    buf[63] = (BYTE)(bitlen      );
    buf[62] = (BYTE)(bitlen >>  8);
    buf[61] = (BYTE)(bitlen >> 16);
    buf[60] = (BYTE)(bitlen >> 24);
    buf[59] = (BYTE)(bitlen >> 32);
    buf[58] = (BYTE)(bitlen >> 40);
    buf[57] = (BYTE)(bitlen >> 48);
    buf[56] = (BYTE)(bitlen >> 56);

    sha256_process_block(H, buf);

    // output H as big-endian bytes
    for (int i = 0; i < 8; ++i) {
        out[4*i + 0] = (BYTE)(H[i] >> 24);
        out[4*i + 1] = (BYTE)(H[i] >> 16);
        out[4*i + 2] = (BYTE)(H[i] >>  8);
        out[4*i + 3] = (BYTE)(H[i]      );
    }
}

// double SHA-256 on arbitrary-length msg
__device__ void double_sha256_any(const BYTE* msg, size_t len, BYTE out[32]) {
    BYTE tmp[32];
    sha256_any(msg, len, tmp);
    sha256_any(tmp, 32, out);
}
void double_sha256(SHA256 *sha256_ctx, unsigned char *bytes, size_t len)
{
    SHA256 tmp;
    sha256(&tmp, (BYTE*)bytes, len);
    sha256(sha256_ctx, (BYTE*)&tmp, sizeof(tmp));
}
// ======================= 80-byte header =========================

// Real 80-byte Bitcoin-like block header
// version (4) + prev_block (32) + merkle_root (32) + time (4) + bits (4) + nonce (4) = 80
struct BlockHeader80 {
    uint32_t version;
    BYTE     prev_block[32];
    BYTE     merkle_root[32];
    uint32_t time;
    uint32_t bits;
    uint32_t nonce;      // little-endian
} __attribute__((packed));

// header template in constant memory (everything except nonce fixed)
__device__ __constant__ BlockHeader80 d_header_template;

// 256-bit target in constant memory, big-endian (32 bytes)
__device__ __constant__ BYTE d_target[32];

struct MiningResult {
    int      found;
    uint32_t nonce;
    BYTE     hash[32];
};

// ================= 256-bit big-endian compare helper ============

// 比較兩個 256-bit big-endian 數字：a vs b
// 回傳：-1 如果 a < b，0 如果 a == b，1 如果 a > b
__device__ int cmp256_be(const BYTE a[32], const BYTE b[32]) {
    for (int i = 0; i < 32; ++i) {
        BYTE x = a[i];
        BYTE y = b[i];
        if (x < y) return -1;
        if (x > y) return 1;
    }
    return 0;
}

// ========================= miner kernel =========================

__global__ void mine_kernel_80(uint64_t start_nonce,
                               uint64_t attempts,
                               MiningResult* result)
{
    uint64_t gid = blockIdx.x * blockDim.x + threadIdx.x;
    if (gid >= attempts) return;

    BlockHeader80 header = d_header_template;

    uint64_t nonce64 = start_nonce + gid;
    uint32_t nonce32 = (uint32_t)nonce64;  // demo: ignore overflow
    header.nonce = nonce32;

    BYTE hash[32];
    double_sha256_any(reinterpret_cast<const BYTE*>(&header),
                      sizeof(BlockHeader80),
                      hash);

    // 真正 target 比較：hash <= target?
// 真正要模仿作業：跟 CPU little_endian_bit_comparison 一樣
if (cmp256_le(hash, d_target) < 0) {   // strict "< 0", same as original code
    int old = atomicCAS(&result->found, 0, 1);
    if (old == 0) {
        result->nonce = nonce32;
        for (int i = 0; i < 32; ++i) {
            result->hash[i] = hash[i];
        }
    }
}
}

// ============================== host ============================
// simple getline for C FILE*, reading up to len-1 chars, stopping at '\n'
void my_getline(char *str, size_t len, FILE *fp)
{
    int i = 0;
    int c;
    while (i < (int)len - 1 && (c = fgetc(fp)) != EOF && c != '\n') {
        str[i++] = (char)c;
    }
    str[i] = '\0';
}

void calc_merkle_root(unsigned char *root, int count, char **branch)
{
    size_t total_count = count; // merkle branch
    unsigned char *raw_list = new unsigned char[(total_count+1)*32];
    unsigned char **list = new unsigned char*[total_count+1];

    // copy each branch to the list
    for(int i=0;i<total_count; ++i)
    {
        list[i] = raw_list + i * 32;
        //convert hex string to bytes array and store them into the list
        convert_string_to_little_endian_bytes(list[i], branch[i], 64);
    }

    list[total_count] = raw_list + total_count*32;


    // calculate merkle root
    while(total_count > 1)
    {
        
        // hash each pair
        int i, j;

        if(total_count % 2 == 1)  //odd, 
        {
            memcpy(list[total_count], list[total_count-1], 32);
        }

        for(i=0, j=0;i<total_count;i+=2, ++j)
        {
            // this part is slightly tricky,
            //   because of the implementation of the double_sha256,
            //   we can avoid the memory begin overwritten during our sha256d calculation
            // double_sha:
            //     tmp = hash(list[0]+list[1])
            //     list[0] = hash(tmp)
            double_sha256((SHA256*)list[j], list[i], 64);
        }

        total_count = j;
    }

    memcpy(root, list[0], 32);

    delete[] raw_list;
    delete[] list;
}

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "usage: %s <in> <out>\n", argv[0]);
        return 1;
    }

    const char *in_path  = argv[1];
    const char *out_path = argv[2];

    FILE *fin  = fopen(in_path, "r");
    if (!fin) {
        perror("fopen input");
        return 1;
    }

    FILE *fout = fopen(out_path, "w");
    if (!fout) {
        perror("fopen output");
        fclose(fin);
        return 1;
    }

    int totalblock = 0;
    if (fscanf(fin, "%d\n", &totalblock) != 1) {
        fprintf(stderr, "Failed to read number of blocks\n");
        fclose(fin);
        fclose(fout);
        return 1;
    }

    // Write number of blocks to output (homework format)
    fprintf(fout, "%d\n", totalblock);

    // We’ll handle each block one by one; for case00.in, totalblock == 1
    for (int bi = 0; bi < totalblock; ++bi) {

        // ---- read block fields (same as original hw4.cu) ----
        char version[9];
        char prevhash[65];
        char ntime[9];
        char nbits[9];
        int  tx;

        getline_hw(version,  9,  fin);
	getline_hw(prevhash, 65, fin);
	getline_hw(ntime,     9, fin);
	getline_hw(nbits,     9, fin);

        if (fscanf(fin, "%d\n", &tx) != 1) {
            fprintf(stderr, "Failed to read tx count\n");
            fclose(fin);
            fclose(fout);
            return 1;
        }

        char *raw_merkle_branch = new char[tx * 65];
        char **merkle_branch    = new char*[tx];

        for (int i = 0; i < tx; ++i) {
            merkle_branch[i] = raw_merkle_branch + i * 65;
            //my_getline(merkle_branch[i], 65, fin);
	    getline_hw(merkle_branch[i], 65, fin);
            merkle_branch[i][64] = '\0';
        }

        // ---- compute merkle root on CPU (same as original) ----
        unsigned char merkle_root[32];
        calc_merkle_root(merkle_root, tx, merkle_branch);

        // Optional debug prints (can comment out for speed)
        printf("Block %d:\n", bi);
        printf("  version:  %s\n", version);
        printf("  prevhash: %s\n", prevhash);
        printf("  merkleroot(little): ");
        print_hex(merkle_root, 32);
        printf("\n");
        printf("  merkleroot(big):    ");
        print_hex_inverse(merkle_root, 32);
        printf("\n");
        printf("  nbits:    %s\n", nbits);
        printf("  ntime:    %s\n", ntime);

        // ---- build 80-byte header on host (BlockHeader80) ----
        BlockHeader80 h_header;
        memset(&h_header, 0, sizeof(h_header));

        // version, time, bits are 4-byte little-endian
        convert_string_to_little_endian_bytes(
            (unsigned char*)&h_header.version, version, 8);
        convert_string_to_little_endian_bytes(
            (unsigned char*)&h_header.time,    ntime,   8);
        convert_string_to_little_endian_bytes(
            (unsigned char*)&h_header.bits,    nbits,   8);

        // prev_block and merkle_root are 32 bytes each
        convert_string_to_little_endian_bytes(
            h_header.prev_block,  prevhash, 64);
        memcpy(h_header.merkle_root, merkle_root, 32);

        h_header.nonce = 0;  // kernel will overwrite this field

        // ---- compute target_hex (little-endian) from nbits (same as hw4) ----
        unsigned int nbits_le = 0;
        convert_string_to_little_endian_bytes(
            (unsigned char*)&nbits_le, nbits, 8);

        unsigned int exp  = nbits_le >> 24;
        unsigned int mant = nbits_le & 0x00ffffffu;

        unsigned char target_hex_le[32] = {};  // little-endian
        unsigned int shift = 8 * (exp - 3);
        unsigned int sb    = shift / 8;
        unsigned int rb    = shift % 8;

        target_hex_le[sb    ] = (mant << rb);
        target_hex_le[sb + 1] = (mant >> (8 - rb));
        target_hex_le[sb + 2] = (mant >> (16 - rb));
        target_hex_le[sb + 3] = (mant >> (24 - rb));

        printf("Target value (big): ");
        print_hex_inverse(target_hex_le, 32);
        printf("\n");

// ---- upload header + target to constant memory ----
cudaMemcpyToSymbol(d_header_template, &h_header, sizeof(BlockHeader80));

// NOTE: d_target holds the same little-endian target_hex as CPU version
cudaMemcpyToSymbol(d_target, target_hex_le, 32);

// ---- set up result buffer on device (allocate ONCE) ----
MiningResult h_result;
h_result.found = 0;
h_result.nonce = 0;
memset(h_result.hash, 0, 32);

MiningResult *d_result = nullptr;
cudaMalloc(&d_result, sizeof(MiningResult));

// how many nonces per kernel launch (chunk size)
const uint64_t attempts_per_launch = 1ull << 24;   // 16,777,216
const uint64_t total_space         = 1ull << 32;   // full 32-bit nonce space

int threadsPerBlock = 256;
int blocks = (int)((attempts_per_launch + threadsPerBlock - 1) / threadsPerBlock);

printf("Scanning full 2^32 nonce space in chunks of %llu...\n",
       (unsigned long long)attempts_per_launch);

bool found = false;

for (uint64_t start_nonce = 0;
     start_nonce < total_space && !found;
     start_nonce += attempts_per_launch)
{
    // reset result on device before each launch
    h_result.found = 0;
    h_result.nonce = 0;
    memset(h_result.hash, 0, 32);
    cudaMemcpy(d_result, &h_result, sizeof(MiningResult), cudaMemcpyHostToDevice);

    printf("  Launch: start_nonce = %10llu, attempts = %10llu\n",
           (unsigned long long)start_nonce,
           (unsigned long long)attempts_per_launch);

    mine_kernel_80<<<blocks, threadsPerBlock>>>(
        start_nonce,
        attempts_per_launch,
        d_result
    );
    cudaDeviceSynchronize();

    cudaMemcpy(&h_result, d_result, sizeof(MiningResult), cudaMemcpyDeviceToHost);

    if (h_result.found) {
        found = true;
        break;
    }
}

cudaFree(d_result);

if (found) {
    printf("Found solution for block %d!\n", bi);
    printf("  nonce = %u (0x%08X)\n", h_result.nonce, h_result.nonce);
    printf("  hash  = ");
    for (int i = 0; i < 32; ++i) printf("%02X", h_result.hash[i]);
    printf("\n");

    // write nonce in little-endian hex, 8 chars, as hw4 does
    unsigned int nonce = h_result.nonce;
    for (int i = 0; i < 4; ++i) {
        fprintf(fout, "%02x", ((unsigned char*)&nonce)[i]);
    }
    fprintf(fout, "\n");
} else {
    printf("No solution in full 2^32 space for block %d (should not happen!).\n", bi);
    fprintf(fout, "00000000\n");
}
        delete[] merkle_branch;
        delete[] raw_merkle_branch;
    }

    fclose(fin);
    fclose(fout);
    return 0;
}
