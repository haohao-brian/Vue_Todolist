//fastest.cpp
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <chrono>
#include <mpi.h>
#include <cstring>
#include <cmath>
#include <omp.h>

#include "image.hpp"
#include "sift.hpp"

// ==== Tunables from your headers (assumed defined there) ====
float sigma_min        = SIGMA_MIN;
int   num_octaves      = N_OCT;
int   scales_per_octave= N_SPO;
float contrast_thresh  = C_DOG;
float edge_thresh      = C_EDGE;
float lambda_ori       = LAMBDA_ORI;
float lambda_desc      = LAMBDA_DESC;

// ==== FAST GAUSSIAN HELPERS (separable, cache-friendly, OpenMP+SIMD) ====
static inline int build_gaussian_kernel(float sigma, std::vector<float>& kernel) {
    if (sigma <= 0.f) { kernel.assign(1, 1.f); return 0; }
    int size = (int)std::ceil(6.f * sigma);
    if (size < 3) size = 3;
    if ((size & 1) == 0) ++size;
    int radius = size / 2;

    kernel.resize(size);
    float sumw = 0.f;
    const float inv2s2 = 1.f / (2.f * sigma * sigma);
    for (int k = -radius; k <= radius; ++k) {
        float w = expf(-(k*k) * inv2s2);
        kernel[k + radius] = w;
        sumw += w;
    }
    float inv = 1.f / sumw;
    for (float& w : kernel) w *= inv;
    return radius;
}

// in[H*W] -> out[H*W], tmp[H*W], clamp borders, kernel.size()==2*radius+1
static inline void gaussian_blur_separable(
    const float* __restrict in,
    float*       __restrict out,
    float*       __restrict tmp,
    int W, int H,
    const float* __restrict kernel,
    int radius
){
    const int KS = 2*radius + 1;

    // Horizontal
    #pragma omp parallel for schedule(static)
    for (int y = 0; y < H; ++y) {
        const float* row_in  = in  + (size_t)y*W;
        float*       row_tmp = tmp + (size_t)y*W;
        for (int x = 0; x < W; ++x) {
            float acc = 0.f;
            #pragma omp simd reduction(+:acc)
            for (int k = -radius; k <= radius; ++k) {
                int xx = x + k;
                if (xx < 0) xx = 0; else if (xx >= W) xx = W-1;
                acc += row_in[xx] * kernel[k + radius];
            }
            row_tmp[x] = acc;
        }
    }

    // Vertical
    #pragma omp parallel for schedule(static)
    for (int y = 0; y < H; ++y) {
        float* row_out = out + (size_t)y*W;
        for (int x = 0; x < W; ++x) {
            float acc = 0.f;
            #pragma omp simd reduction(+:acc)
            for (int k = -radius; k <= radius; ++k) {
                int yy = y + k;
                if (yy < 0) yy = 0; else if (yy >= H) yy = H-1;
                acc += tmp[(size_t)yy*W + x] * kernel[k + radius];
            }
            row_out[x] = acc;
        }
    }
}

// ==== FAST GRADIENT (gx, gy), OpenMP+SIMD ====
static inline void compute_grad_xy(
    const float* __restrict src, int W, int H,
    float*       __restrict gx,
    float*       __restrict gy
){
    #pragma omp parallel for collapse(2) schedule(static)
    for (int y = 1; y < H-1; ++y) {
        for (int x = 1; x < W-1; ++x) {
            const float r = src[(size_t)y*W + (x+1)];
            const float l = src[(size_t)y*W + (x-1)];
            const float u = src[(size_t)(y-1)*W + x];
            const float d = src[(size_t)(y+1)*W + x];
            gx[(size_t)y*W + x] = 0.5f * (r - l);
            gy[(size_t)y*W + x] = 0.5f * (d - u);
        }
    }
    // (Optionally set borders to 0)
}

// ==== MAIN ====
int main(int argc, char *argv[])
{
    MPI_Init(&argc, &argv);
    MPI_Comm comm = MPI_COMM_WORLD;
    int rank = 0, comm_sz = 1;
    MPI_Comm_rank(comm, &rank);
    MPI_Comm_size(comm, &comm_sz);

    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    if (rank == 0 && argc != 4) {
        std::cerr << "Usage: ./hw2 ./testcases/xx.jpg ./results/xx.jpg ./results/xx.txt\n";
        MPI_Abort(comm, 1);
    }

    std::string input_img, output_img, output_txt;
    if (rank == 0) {
        input_img  = argv[1];
        output_img = argv[2];
        output_txt = argv[3];
    }

    auto t_all_start = std::chrono::high_resolution_clock::now();

    // 1) Load on rank 0
    Image img;
    int width = 0, height = 0, channels = 0;
    if (rank == 0) {
        img = Image(input_img);
        width = img.width;
        height = img.height;
        channels = img.channels;
    }

    // bcast meta
    MPI_Bcast(&width,    1, MPI_INT, 0, comm);
    MPI_Bcast(&height,   1, MPI_INT, 0, comm);
    MPI_Bcast(&channels, 1, MPI_INT, 0, comm);

    if (width <= 0 || height <= 0) {
        if (rank == 0) std::cerr << "Invalid image dimensions.\n";
        MPI_Finalize();
        return 1;
    }

    // 2) MPI grayscale scatter/gather
    const int N = width * height;
    std::vector<int> counts(comm_sz), displs(comm_sz);
    {
        int base = N / comm_sz, rem = N % comm_sz, off = 0;
        for (int r = 0; r < comm_sz; ++r) {
            counts[r] = base + (r < rem ? 1 : 0);
            displs[r] = off;
            off += counts[r];
        }
    }
    const int nloc = counts[rank];

    std::vector<float> local_gray(nloc);
    std::vector<float> local_r, local_g, local_b;
    std::vector<float> gray_data; if (rank == 0) gray_data.resize(N);

    if (channels == 1) {
        MPI_Scatterv(
            (rank == 0 ? img.data : nullptr), counts.data(), displs.data(), MPI_FLOAT,
            local_gray.data(), nloc, MPI_FLOAT,
            0, comm
        );
    } else {
        // assume planar R,G,B in img.data: [0..N-1],[N..2N-1],[2N..3N-1]
        local_r.resize(nloc);
        local_g.resize(nloc);
        local_b.resize(nloc);
        MPI_Scatterv((rank == 0 ? img.data + 0*N : nullptr), counts.data(), displs.data(), MPI_FLOAT,
                     local_r.data(), nloc, MPI_FLOAT, 0, comm);
        MPI_Scatterv((rank == 0 ? img.data + 1*N : nullptr), counts.data(), displs.data(), MPI_FLOAT,
                     local_g.data(), nloc, MPI_FLOAT, 0, comm);
        MPI_Scatterv((rank == 0 ? img.data + 2*N : nullptr), counts.data(), displs.data(), MPI_FLOAT,
                     local_b.data(), nloc, MPI_FLOAT, 0, comm);

        for (int i = 0; i < nloc; ++i) {
            local_gray[i] = 0.299f*local_r[i] + 0.587f*local_g[i] + 0.114f*local_b[i];
        }
    }

    MPI_Gatherv(
        local_gray.data(), nloc, MPI_FLOAT,
        (rank == 0 ? gray_data.data() : nullptr), counts.data(), displs.data(), MPI_FLOAT,
        0, comm
    );

    // 3) Single-rank SIFT pipeline
    if (rank == 0) {
        Image gray(width, height, 1);
        std::memcpy(gray.data, gray_data.data(), sizeof(float)*(size_t)N);
        Image input = gray;

        // --- Build base image: 2x resize + blur(sigma_diff) ---
        auto t0 = std::chrono::high_resolution_clock::now();

        Image base_img(input.width*2, input.height*2, 1);
        float base_sigma = sigma_min / MIN_PIX_DIST;
        float sigma_diff = std::sqrt(base_sigma*base_sigma - 1.0f);

        // resize (use your existing function)
        float* tmp_resize = resize_by_data(input.data, input.width, input.height,
                                           base_img.width, base_img.height,
                                           1, Interpolation::BILINEAR);
        std::memcpy(base_img.data, tmp_resize, sizeof(float)*(size_t)base_img.size);
        std::free(tmp_resize);

        // separable blur
        std::vector<float> kernel;
        int radius = build_gaussian_kernel(sigma_diff, kernel);
        std::vector<float> scratch((size_t)base_img.size);
        gaussian_blur_separable(
            base_img.data, base_img.data, scratch.data(),
            base_img.width, base_img.height,
            kernel.data(), radius
        );

        // --- Precompute sigma deltas for each level ---
        const int imgs_per_octave = scales_per_octave + 3;
        const float k = std::pow(2.0f, 1.0f / (float)scales_per_octave);
        std::vector<float> sig_delta(imgs_per_octave);
        sig_delta[0] = 0.f;
        for (int i = 1; i < imgs_per_octave; ++i) {
            float sigma_prev  = base_sigma * std::pow(k, i-1);
            float sigma_total = k * sigma_prev;
            sig_delta[i]      = std::sqrt(sigma_total*sigma_total - sigma_prev*sigma_prev);
        }

        // --- Gaussian pyramid (fast, memory-safe) ---
        ScaleSpacePyramid gaussian_pyramid {
            num_octaves,
            imgs_per_octave,
            std::vector<std::vector<Image>>(num_octaves)
        };

        Image cur_base = base_img;
        std::vector<float> kbuf; // kernel reuse buffer
        for (int oct = 0; oct < num_octaves; ++oct) {
            gaussian_pyramid.octaves[oct].reserve(imgs_per_octave);

            // level 0: cur_base
            gaussian_pyramid.octaves[oct].push_back(cur_base);
            const Image* prev = &gaussian_pyramid.octaves[oct].back();

            // levels 1..S: progressive blur
            for (int s = 1; s < imgs_per_octave; ++s) {
                const float sig = sig_delta[s];
                Image level(prev->width, prev->height, 1);

                int r = build_gaussian_kernel(sig, kbuf);
                gaussian_blur_separable(
                    prev->data, level.data, scratch.data(),
                    prev->width, prev->height,
                    kbuf.data(), r
                );
                gaussian_pyramid.octaves[oct].push_back(std::move(level));
                prev = &gaussian_pyramid.octaves[oct].back();
            }

            // next octave base = level imgs_per_octave-3
            const Image& nb = gaussian_pyramid.octaves[oct][imgs_per_octave - 3];
            Image next_base(nb.width/2, nb.height/2, 1);

            float* ds = resize_by_data(nb.data, nb.width, nb.height,
                                       next_base.width, next_base.height,
                                       1, Interpolation::NEAREST);
            std::memcpy(next_base.data, ds, sizeof(float)*(size_t)next_base.size);
            std::free(ds);

            cur_base = std::move(next_base);
        }

        auto t1 = std::chrono::high_resolution_clock::now();
        std::cout << "generate_gaussian_pyramid (fast): "
                  << std::chrono::duration<double, std::milli>(t1 - t0).count() << " ms\n";

        // --- DoG + keypoints ---
        t0 = std::chrono::high_resolution_clock::now();
        ScaleSpacePyramid dog_pyramid = generate_dog_pyramid(gaussian_pyramid);
        t1 = std::chrono::high_resolution_clock::now();
        std::cout << "generate_dog_pyramid: "
                  << std::chrono::duration<double, std::milli>(t1 - t0).count() << " ms\n";

        t0 = std::chrono::high_resolution_clock::now();
        std::vector<Keypoint> tmp_kps = find_keypoints(dog_pyramid, contrast_thresh, edge_thresh);
        t1 = std::chrono::high_resolution_clock::now();
        std::cout << "find_keypoints: "
                  << std::chrono::duration<double, std::milli>(t1 - t0).count() << " ms\n";

        // --- Gradient pyramid (gx, gy) ---
        t0 = std::chrono::high_resolution_clock::now();
        ScaleSpacePyramid grad_pyramid {
            gaussian_pyramid.num_octaves,
            gaussian_pyramid.imgs_per_octave,
            std::vector<std::vector<Image>>(gaussian_pyramid.num_octaves)
        };

        for (int i = 0; i < gaussian_pyramid.num_octaves; i++) {
            grad_pyramid.octaves[i].reserve(grad_pyramid.imgs_per_octave);
            int W = gaussian_pyramid.octaves[i][0].width;
            int H = gaussian_pyramid.octaves[i][0].height;

            for (int j = 0; j < gaussian_pyramid.imgs_per_octave; j++) {
                const Image& src = gaussian_pyramid.octaves[i][j];
                Image grad(W, H, 2);
                float* gx = grad.data;
                float* gy = grad.data + (size_t)W*H;
                compute_grad_xy(src.data, W, H, gx, gy);
                grad_pyramid.octaves[i].push_back(std::move(grad));
            }
        }

        t1 = std::chrono::high_resolution_clock::now();
        std::cout << "generate_gradient_pyramid (fast): "
                  << std::chrono::duration<double, std::milli>(t1 - t0).count() << " ms\n";

        // --- Orientations & descriptors (OpenMP) ---
        t0 = std::chrono::high_resolution_clock::now();
        std::vector<Keypoint> kps;

        #pragma omp parallel
        {
            std::vector<Keypoint> local;
            #pragma omp for schedule(dynamic)
            for (int i = 0; i < (int)tmp_kps.size(); ++i) {
                Keypoint kp_tmp = tmp_kps[i];
                std::vector<float> orientations =
                    find_keypoint_orientations(kp_tmp, grad_pyramid, lambda_ori, lambda_desc);
                for (float theta : orientations) {
                    Keypoint kp = kp_tmp;
                    compute_keypoint_descriptor(kp, theta, grad_pyramid, lambda_desc);
                    local.push_back(std::move(kp));
                }
            }
            #pragma omp critical
            kps.insert(kps.end(), local.begin(), local.end());
        }
        t1 = std::chrono::high_resolution_clock::now();
        std::cout << "descriptor loop: "
                  << std::chrono::duration<double, std::milli>(t1 - t0).count() << " ms\n";

        // --- Validation output ---
        std::ofstream ofs(output_txt);
        if (!ofs) {
            std::cerr << "Failed to open " << output_txt << " for writing.\n";
        } else {
            ofs << kps.size() << "\n";
            for (const auto& kp : kps) {
                ofs << kp.i << " " << kp.j << " " << kp.octave << " " << kp.scale << " ";
                for (size_t i = 0; i < kp.descriptor.size(); ++i) ofs << " " << (int)kp.descriptor[i];
                ofs << "\n";
            }
        }

        Image result = draw_keypoints(gray, kps);
        result.save(output_img);

        auto t_all_end = std::chrono::high_resolution_clock::now();
        std::cout << "Total time: "
                  << std::chrono::duration<double, std::milli>(t_all_end - t_all_start).count()
                  << " ms\n";
        std::cout << "Found " << kps.size() << " keypoints.\n";
    }

    MPI_Finalize();
    return 0;
}

