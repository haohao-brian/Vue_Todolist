#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <chrono>
#include <mpi.h>
#include <cstring>
#include <cmath> 

#include "image.hpp"
#include "sift.hpp"
float sigma_min=SIGMA_MIN;
int num_octaves=N_OCT;
int scales_per_octave=N_SPO;
float contrast_thresh=C_DOG;
float edge_thresh=C_EDGE;
float lambda_ori=LAMBDA_ORI;
float lambda_desc=LAMBDA_DESC;
int main(int argc, char *argv[])
{
    MPI_Init(&argc, &argv);
    MPI_Comm comm = MPI_COMM_WORLD;
    int rank = 0, comm_sz = 1;
    MPI_Comm_rank(comm, &rank);
    MPI_Comm_size(comm, &comm_sz);

    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    if (rank == 0 && argc != 4) {
        std::cerr << "Usage: ./hw2 ./testcases/xx.jpg ./results/xx.jpg ./results/xx.txt\n";
        MPI_Abort(comm, 1);
    }

    std::string input_img, output_img, output_txt;
    if (rank == 0) {
        input_img = argv[1];
        output_img = argv[2];
        output_txt = argv[3];
    }

    auto start = std::chrono::high_resolution_clock::now();
    auto start1 = std::chrono::high_resolution_clock::now();

    // --- root loads image ---
    Image img;
    int width = 0, height = 0, channels = 0;
    if (rank == 0) {
        img = Image(input_img);
        width = img.width;
        height = img.height;
        channels = img.channels;
    }

    // broadcast shape/meta
    MPI_Bcast(&width,    1, MPI_INT, 0, comm);
    MPI_Bcast(&height,   1, MPI_INT, 0, comm);
    MPI_Bcast(&channels, 1, MPI_INT, 0, comm);

    if (width == 0 || height == 0) {
        if (rank == 0) std::cerr << "Invalid image dimensions.\n";
        MPI_Finalize();
        return 1;
    }

    const int N = width * height;      // number of pixels (not elements)
    // We’ll compute grayscale: 1 float per pixel.
    // If input has 3 channels, we’ll scatter each plane separately.

    // build counts/displs for pixel-slices (uneven split ok)
    std::vector<int> counts(comm_sz), displs(comm_sz);
    {
        int base = N / comm_sz, rem = N % comm_sz, off = 0;
        for (int r = 0; r < comm_sz; ++r) {
            counts[r] = base + (r < rem ? 1 : 0);
            displs[r] = off;
            off += counts[r];
        }
    }
    const int nloc = counts[rank];

    // local buffers
    std::vector<float> local_gray(nloc);
    std::vector<float> local_r, local_g, local_b;

    // root-only global gray buffer for gather
    std::vector<float> gray_data; // size N
    if (rank == 0) gray_data.resize(N);

    // If the source image is already single-channel, we can just scatter that one plane.
    if (channels == 1) {
        // Scatter one plane (img.data has N floats)
        MPI_Scatterv(
            (rank == 0 ? img.data : nullptr), counts.data(), displs.data(), MPI_FLOAT,
            local_gray.data(), nloc, MPI_FLOAT,
            0, comm
        );
    } else {
        // Assume planar layout as your original indexing implies:
        // R plane [0..N-1], G plane [N..2N-1], B plane [2N..3N-1]
        // If your Image is interleaved, convert to planar on root first.

        local_r.resize(nloc);
        local_g.resize(nloc);
        local_b.resize(nloc);

        // scatter each plane
        MPI_Scatterv(
            (rank == 0 ? img.data + 0 * N : nullptr), counts.data(), displs.data(), MPI_FLOAT,
            local_r.data(), nloc, MPI_FLOAT, 0, comm);
        MPI_Scatterv(
            (rank == 0 ? img.data + 1 * N : nullptr), counts.data(), displs.data(), MPI_FLOAT,
            local_g.data(), nloc, MPI_FLOAT, 0, comm);
        MPI_Scatterv(
            (rank == 0 ? img.data + 2 * N : nullptr), counts.data(), displs.data(), MPI_FLOAT,
            local_b.data(), nloc, MPI_FLOAT, 0, comm);

        // local grayscale
        for (int i = 0; i < nloc; ++i) {
            local_gray[i] = 0.299f * local_r[i] + 0.587f * local_g[i] + 0.114f * local_b[i];
        }
    }

    // gather grayscale back to root
    MPI_Gatherv(
        local_gray.data(), nloc, MPI_FLOAT,
        (rank == 0 ? gray_data.data() : nullptr), counts.data(), displs.data(), MPI_FLOAT,
        0, comm
    );

    // --- after gather, only root needs the full image for SIFT ---
    std::vector<Keypoint> kps;
    Image result;
    Image gray(width, height, 1);
    if (rank == 0) {
        // attach/copy the gathered data into gray
        // If Image takes ownership, you could move; otherwise copy:
        std::memcpy(gray.data, gray_data.data(), sizeof(float) * N);
    }
    if (rank == 0) {
        // run SIFT on grayscale image
        //kps = find_keypoints_and_descriptors(gray);
    }
    //auto start = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration;
    auto end = std::chrono::high_resolution_clock::now();
    Image input;
    if (rank == 0) {
        // run SIFT on grayscale image
        Image img = gray;

        //assert(img.channels == 1 || img.channels == 3);

        input = img.channels == 1 ? img : rgb_to_grayscale(img);

        end = std::chrono::high_resolution_clock::now();
        duration = end - start;
        std::cout << duration.count() << " ms\n";
        start = std::chrono::high_resolution_clock::now();
    }   
    ScaleSpacePyramid gaussian_pyramid;
    if (rank == 0) {
        //gaussian_pyramid = generate_gaussian_pyramid(input, sigma_min, num_octaves,scales_per_octave);
    }
    if (rank == 0){
        // assume initial sigma is 1.0 (after resizing) and smooth
        // the image with sigma_diff to reach requried base_sigma
        img = input;
        float base_sigma = sigma_min / MIN_PIX_DIST;
        float sigma_diff = std::sqrt(base_sigma*base_sigma - 1.0f);

        Image base_img(img.width*2, img.height*2, img.channels);

        //float* data1 = img.data;

        float* out1 = resize_by_data(img.data, img.width, 
                 img.height, img.width*2, img.height*2,
                  img.channels, Interpolation::BILINEAR);
        std::free(base_img.data);            // free the old buffer FIRST
        base_img.data = out1;                 // take ownership of the new buffer
        //base_img = img.resize(img.width*2, img.height*2, Interpolation::BILINEAR);

        float *out = gaussian_blur_by_data(base_img.data, base_img.width, base_img.height, sigma_diff);
        std::free(base_img.data);            // free the old buffer FIRST
        base_img.data = out;                 // take ownership of the new buffer
        //data = gaussian_blur_by_data(data,base_img.width,base_img.height,sigma_diff);

        int imgs_per_octave = scales_per_octave + 3;

        // determine sigma values for bluring
        float k = std::pow(2, 1.0/scales_per_octave);
        std::vector<float> sigma_vals {base_sigma};
        for (int i = 1; i < imgs_per_octave; i++) {
            float sigma_prev = base_sigma * std::pow(k, i-1);
            float sigma_total = k * sigma_prev;
            sigma_vals.push_back(std::sqrt(sigma_total*sigma_total - sigma_prev*sigma_prev));
        }

        // create a scale space pyramid of gaussian images
        // images in each octave are half the size of images in the previous one
        ScaleSpacePyramid pyramid = {
            num_octaves,
            imgs_per_octave,
            std::vector<std::vector<Image>>(num_octaves)
        };
        for (int i = 0; i < num_octaves; i++) {
            pyramid.octaves[i].reserve(imgs_per_octave);
            pyramid.octaves[i].push_back(std::move(base_img));
            for (int j = 1; j < sigma_vals.size(); j++) {
                const Image& prev_img = pyramid.octaves[i].back();
                pyramid.octaves[i].push_back(gaussian_blur(prev_img, sigma_vals[j]));
            }
            // prepare base image for next octave
            const Image& next_base_img = pyramid.octaves[i][imgs_per_octave-3];
            base_img = next_base_img.resize(next_base_img.width/2, next_base_img.height/2,
                                            Interpolation::NEAREST);
        }
        gaussian_pyramid =  pyramid;
    }
    if (rank == 0) {                                                                
        end = std::chrono::high_resolution_clock::now();
        duration = end - start;
        std::cout << "generate_gaussian_pyramid-Execution time: " << duration.count() << " ms\n";
        start = std::chrono::high_resolution_clock::now();

        ScaleSpacePyramid dog_pyramid = generate_dog_pyramid(gaussian_pyramid);
        
        end = std::chrono::high_resolution_clock::now();
        duration = end - start;
        std::cout << "generate_dog_pyramid-Execution time: " << duration.count() << " ms\n";
        start = std::chrono::high_resolution_clock::now();

        std::vector<Keypoint> tmp_kps = find_keypoints(dog_pyramid, contrast_thresh, edge_thresh);
        
        end = std::chrono::high_resolution_clock::now();
        duration = end - start;
        std::cout << "find_keypoints-Execution time: " << duration.count() << " ms\n";
        start = std::chrono::high_resolution_clock::now();
        
        ScaleSpacePyramid grad_pyramid = generate_gradient_pyramid(gaussian_pyramid);
        
        end = std::chrono::high_resolution_clock::now();
        duration = end - start;
        std::cout << "generate_gradient_pyramid-Execution time: " << duration.count() << " ms\n";
        start = std::chrono::high_resolution_clock::now();

        //std::vector<Keypoint> kps;

        for (Keypoint& kp_tmp : tmp_kps) {
            std::vector<float> orientations = find_keypoint_orientations(kp_tmp, grad_pyramid,
                                                                        lambda_ori, lambda_desc);
            for (float theta : orientations) {
                Keypoint kp = kp_tmp;
                compute_keypoint_descriptor(kp, theta, grad_pyramid, lambda_desc);
                kps.push_back(kp);
            }
        }
        end = std::chrono::high_resolution_clock::now();
        duration = end - start;
        std::cout << "for loop-Execution time: " << duration.count() << " ms\n";
        start = std::chrono::high_resolution_clock::now();
        //return kps;
    }
    if (rank == 0) {
        // validation output
        std::ofstream ofs(output_txt);
        if (!ofs) {
            std::cerr << "Failed to open " << output_txt << " for writing.\n";
        } else {
            ofs << kps.size() << "\n";
            for (const auto& kp : kps) {
                ofs << kp.i << " " << kp.j << " " << kp.octave << " " << kp.scale << " ";
                for (size_t i = 0; i < kp.descriptor.size(); ++i) {
                    ofs << " " << static_cast<int>(kp.descriptor[i]);
                }
                ofs << "\n";
            }
        }

        result = draw_keypoints(gray, kps);
        result.save(output_img);
    }

    MPI_Finalize();

    if (rank == 0) {
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double, std::milli> duration = end - start1;
        std::cout << "Execution time: " << duration.count() << " ms\n";
        std::cout << "Found " << kps.size() << " keypoints.\n";
    }
    return 0;
}

