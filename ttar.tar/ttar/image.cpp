#include <array>
#include <cmath>
#include <iostream>
#include <cassert>
#include <utility>

#include "image.hpp"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

Image::Image(std::string file_path)
{
    unsigned char *img_data = stbi_load(file_path.c_str(), &width, &height, &channels, 0);
    if (img_data == nullptr) {
        const char *error_msg = stbi_failure_reason();
        std::cerr << "Failed to load image: " << file_path.c_str() << "\n";
        std::cerr << "Error msg (stb_image): " << error_msg << "\n";
        std::exit(1);
    }

    size = width * height * channels;
    data = new float[size]; 
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < width; x++) {
        for (int y = 0; y < height; y++) {
            for (int c = 0; c < channels; c++) {
                int src_idx = y*width*channels + x*channels + c;
                int dst_idx = c*height*width + y*width + x;
                data[dst_idx] = img_data[src_idx] / 255.;
            }
        }
    }
    if (channels == 4)
        channels = 3; //ignore alpha channel
    stbi_image_free(img_data);
}

Image::Image(int w, int h, int c)
    :width {w},
     height {h},
     channels {c},
     size {w*h*c},
     data {new float[w*h*c]()}
{
}

Image::Image()
    :width {0},
     height {0},
     channels {0},
     size {0},
     data {nullptr} 
{
}

Image::~Image()
{
    delete[] this->data;
}

Image::Image(const Image& other)
    :width {other.width},
     height {other.height},
     channels {other.channels},
     size {other.size},
     data {new float[other.size]}
{
    //std::cout << "copy constructor\n";
    //#pragma omp parallel for
    for (int i = 0; i < size; i++)
        data[i] = other.data[i];
}

Image& Image::operator=(const Image& other)
{
    if (this != &other) {
        delete[] data;
        //std::cout << "copy assignment\n";
        width = other.width;
        height = other.height;
        channels = other.channels;
        size = other.size;
        data = new float[other.size];
        for (int i = 0; i < other.size; i++)
            data[i] = other.data[i];
    }
    return *this;
}

Image::Image(Image&& other)
    :width {other.width},
     height {other.height},
     channels {other.channels},
     size {other.size},
     data {other.data}
{
    //std::cout << "move constructor\n";
    other.data = nullptr;
    other.size = 0;
}

Image& Image::operator=(Image&& other)
{
    //std::cout << "move assignment\n";
    delete[] data;
    data = other.data;
    width = other.width;
    height = other.height;
    channels = other.channels;
    size = other.size;

    other.data = nullptr;
    other.size = 0;
    return *this;
}

//save image as jpg file
bool Image::save(std::string file_path)
{
    unsigned char *out_data = new unsigned char[width*height*channels]; 
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < width; x++) {
        for (int y = 0; y < height; y++) {
            for (int c = 0; c < channels; c++) {
                int dst_idx = y*width*channels + x*channels + c;
                int src_idx = c*height*width + y*width + x;
                out_data[dst_idx] = std::roundf(data[src_idx] * 255.);
            }
        }
    }
    bool success = stbi_write_jpg(file_path.c_str(), width, height, channels, out_data, 100);
    if (!success)
        std::cerr << "Failed to save image: " << file_path << "\n";

    delete[] out_data;
    return true;
}

void Image::set_pixel(int x, int y, int c, float val)
{
    if (x >= width || x < 0 || y >= height || y < 0 || c >= channels || c < 0) {
        std::cerr << "set_pixel() error: Index out of bounds.\n";
        std::exit(1);
    }
    data[c*width*height + y*width + x] = val;
}

float Image::get_pixel(int x, int y, int c) const
{
    if (x < 0)
        x = 0;
    if (x >= width)
        x = width - 1;
    if (y < 0)
        y = 0;
    if (y >= height)
        y = height - 1;
    return data[c*width*height + y*width + x];
}

void Image::clamp()
{
    int size = width * height * channels;
    #pragma omp parallel for
    for (int i = 0; i < size; i++) {
        float val = data[i];
        val = (val > 1.0) ? 1.0 : val;
        val = (val < 0.0) ? 0.0 : val;
        data[i] = val;
    }
}

//map coordinate from 0-current_max range to 0-new_max range
float map_coordinate(float new_max, float current_max, float coord)
{
    float a = new_max / current_max;
    float b = -0.5 + a*0.5;
    return a*coord + b;
}

Image Image::resize(int new_w, int new_h, Interpolation method) const
{
    Image resized(new_w, new_h, this->channels);
    float value = 0;
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < new_w; x++) {
        for (int y = 0; y < new_h; y++) {
            for (int c = 0; c < resized.channels; c++) {
                float old_x = map_coordinate(this->width, new_w, x);
                float old_y = map_coordinate(this->height, new_h, y);
                if (method == Interpolation::BILINEAR)
                    value = bilinear_interpolate(*this, old_x, old_y, c);
                else if (method == Interpolation::NEAREST)
                    value = nn_interpolate(*this, old_x, old_y, c);
                resized.set_pixel(x, y, c, value);
            }
        }
    }
    return resized;
}
float* resize_by_data(float * img, int width, int height,int new_w, int new_h,int channels, Interpolation method)
{
    float* resized = (float *)malloc(new_w * new_h * channels*sizeof(float));
    //[new_w * new_h * channels];
    float value = 0;
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < new_w; x++) {
        for (int y = 0; y < new_h; y++) {
            for (int c = 0; c < channels; c++) {
                float old_x = map_coordinate(width, new_w, x);
                float old_y = map_coordinate(height, new_h, y);
                if (method == Interpolation::BILINEAR){
                    value = bilinear_interpolate_by_data(img, width, height, old_x, old_y, c);
                }else if (method == Interpolation::NEAREST){
                    value = nn_interpolate_by_data(img, width, height, old_x, old_y, c);
                }
                resized[c*new_w*new_h + y*new_w + x] = value;
                //resized.set_pixel(x, y, c, value);
            }
        }
    }
    return resized;
}
/*
std::array<Image, 4> separate_quadrants(const Image& img)
{
    int left_w = img.width / 2 + 20;
    int right_w = img.width - img.width / 2 + 20;
    int top_h = img.height / 2 + 20;
    int bottom_h = img.height - img.height/2 + 20;
    int channels = img.channels;

    std::array<Image, 4> quadrants = {
        Image(left_w, top_h, channels),
        Image(right_w, top_h, channels),
        Image(left_w, bottom_h, channels),
        Image(right_w, bottom_h, channels)
    };
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < left_w; ++x) {
        for (int y = 0; y < top_h; ++y) {
            for (int c = 0; c < channels; ++c) {
                quadrants[0].set_pixel(x, y, c, img.get_pixel(x, y, c));
            }
        }
    }

    #pragma omp parallel for collapse(2)
    for (int x = 0; x < right_w; ++x) {
        for (int y = 0; y < top_h; ++y) {
            for (int c = 0; c < channels; ++c) {
                quadrants[1].set_pixel(x, y, c, img.get_pixel(x + img.width - right_w, y, c));
            }
        }
    }

    #pragma omp parallel for collapse(2)
    for (int x = 0; x < left_w; ++x) {
        for (int y = 0; y < bottom_h; ++y) {
            for (int c = 0; c < channels; ++c) {
                quadrants[2].set_pixel(x, y, c, img.get_pixel(x, y + img.height - bottom_h, c));
            }
        }
    }

    #pragma omp parallel for collapse(2)
    for (int x = 0; x < right_w; ++x) {
        for (int y = 0; y < bottom_h; ++y) {
            for (int c = 0; c < channels; ++c) {
                quadrants[3].set_pixel(x, y, c, img.get_pixel(x + img.width - right_w, y + img.height - bottom_h, c));
            }
        }
    }

    return quadrants;
}
*/
std::array<Image, 4> separate_quadrants(const Image& img)
{
    int left_w = img.width / 2 + 20;
    int right_w = img.width - img.width / 2 + 20;
    int top_h = img.height / 2 + 20;
    int bottom_h = img.height - img.height/2 + 20;
    int channels = img.channels;

    std::array<Image, 4> quadrants = {
        Image(left_w, top_h, channels),
        Image(right_w, top_h, channels),
        Image(left_w, bottom_h, channels),
        Image(right_w, bottom_h, channels)
    };
    auto copy_tile = [&](Image& dst, int dst_width, int dst_height,
                         int src_x_offset, int src_y_offset)
    {
        float* dst_data = dst.data;
        int dst_w = dst.width;
        int dst_h = dst.height;
        for (int y = 0; y < dst_height; ++y) {
            int src_y = y + src_y_offset;
            for (int x = 0; x < dst_width; ++x) {
                int src_x = x + src_x_offset;
                for (int c = 0; c < channels; ++c) {
                    dst_data[c*dst_w*dst_h + y*dst_w + x] =
                        img.get_pixel(src_x, src_y, c);
                }
            }
        }
    };

    #pragma omp parallel
    {
        #pragma omp sections nowait
        {
            #pragma omp section
            copy_tile(quadrants[0], left_w, top_h, 0, 0);

            #pragma omp section
            copy_tile(quadrants[1], right_w, top_h,
                      img.width - right_w, 0);

            #pragma omp section
            copy_tile(quadrants[2], left_w, bottom_h,
                      0, img.height - bottom_h);

            #pragma omp section
            copy_tile(quadrants[3], right_w, bottom_h,
                      img.width - right_w, img.height - bottom_h);
        }
    }

    return quadrants;
}
Image merge_quadrants(const std::array<Image, 4>& quadrants)
{
    int channels = quadrants[0].channels;

    assert(quadrants[1].channels == channels);
    assert(quadrants[2].channels == channels);
    assert(quadrants[3].channels == channels);
    assert(quadrants[0].height == quadrants[1].height);
    assert(quadrants[2].height == quadrants[3].height);
    assert(quadrants[0].width == quadrants[2].width);
    assert(quadrants[1].width == quadrants[3].width);

    int left_w = quadrants[0].width;
    int right_w = quadrants[1].width;
    int top_h = quadrants[0].height;
    int bottom_h = quadrants[2].height;

    int width = left_w+right_w - 20 - 20;
    int height = top_h+bottom_h - 20 - 20;
    //Image merged(left_w + right_w-20, top_h + bottom_h-20, channels);
    Image merged(width, height, channels);
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < left_w-20; ++x) {
        for (int y = 0; y < top_h-20; ++y) {
            for (int c = 0; c < channels; ++c) {
                merged.set_pixel(x, y, c, quadrants[0].get_pixel(x, y, c));
            }
        }
    }

    #pragma omp parallel for collapse(2)
    for (int x = 20; x < right_w; ++x) {
        for (int y = 0; y < top_h; ++y) {
            for (int c = 0; c < channels; ++c) {
                merged.set_pixel(x + width - right_w, y, c, quadrants[1].get_pixel(x, y, c));
            }
        }
    }

    #pragma omp parallel for collapse(2)
    for (int x = 0; x < left_w; ++x) {
        for (int y = 20; y < bottom_h; ++y) {
            for (int c = 0; c < channels; ++c) {
                merged.set_pixel(x, y + height - bottom_h, c, quadrants[2].get_pixel(x, y, c));
            }
        }
    }

    #pragma omp parallel for collapse(2)
    for (int x = 20; x < right_w; ++x) {
        for (int y = 20; y < bottom_h; ++y) {
            for (int c = 0; c < channels; ++c) {
                merged.set_pixel(x + width - right_w, y + height - bottom_h, c, quadrants[3].get_pixel(x, y, c));
            }
        }
    }

    return merged;
}

float bilinear_interpolate(const Image& img, float x, float y, int c)
{
    float p1, p2, p3, p4, q1, q2;
    float x_floor = std::floor(x), y_floor = std::floor(y);
    float x_ceil = x_floor + 1, y_ceil = y_floor + 1;
    p1 = img.get_pixel(x_floor, y_floor, c);
    p2 = img.get_pixel(x_ceil, y_floor, c);
    p3 = img.get_pixel(x_floor, y_ceil, c);
    p4 = img.get_pixel(x_ceil, y_ceil, c);
    q1 = (y_ceil-y)*p1 + (y-y_floor)*p3;
    q2 = (y_ceil-y)*p2 + (y-y_floor)*p4;
    return (x_ceil-x)*q1 + (x-x_floor)*q2;
}
float nn_interpolate(const Image& img, float x, float y, int c)
{
    return img.get_pixel(std::round(x), std::round(y), c);
}
float nn_interpolate_by_data(float * img,int width, int height, float x, float y, int c)
{
    int yy = (int)round(y);
    int xx = (int)round(x);
    return img[c*width*height + yy*width + xx];
    //img.get_pixel(std::round(x), std::round(y), c);
}
static inline int clampi(int v, int lo, int hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}
float bilinear_interpolate_by_data(float *img, int width, int height, float x, float y, int c)
{
    float p1, p2, p3, p4, q1, q2;
    int x_floor = std::floor(x), y_floor = std::floor(y);
    int x_ceil = x_floor + 1, y_ceil = y_floor + 1;
    x_ceil = clampi(x_ceil, 0, width - 1);
    y_ceil = clampi(y_ceil, 0, height - 1);
    x_floor = clampi(x_floor, 0, width - 1);
    y_floor = clampi(y_floor, 0, height - 1);
    p1 = img[c*width*height + y_floor*width + x_floor];
    p2 = img[c*width*height + y_floor*width + x_ceil];
    p3 = img[c*width*height + y_ceil*width + x_floor];
    p4 = img[c*width*height + y_ceil*width + x_ceil];
    //p1 = img.get_pixel(x_floor, y_floor, c);
    //p2 = img.get_pixel(x_ceil, y_floor, c);
    //p3 = img.get_pixel(x_floor, y_ceil, c);
    //p4 = img.get_pixel(x_ceil, y_ceil, c);
    q1 = (y_ceil-y)*p1 + (y-y_floor)*p3;
    q2 = (y_ceil-y)*p2 + (y-y_floor)*p4;
    return (x_ceil-x)*q1 + (x-x_floor)*q2;
}


Image rgb_to_grayscale(const Image& img)
{
    assert(img.channels == 3);
    Image gray(img.width, img.height, 1);
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < img.width; x++) {
        for (int y = 0; y < img.height; y++) {
            float red, green, blue;
            red = img.get_pixel(x, y, 0);
            green = img.get_pixel(x, y, 1);
            blue = img.get_pixel(x, y, 2);
            gray.set_pixel(x, y, 0, 0.299*red + 0.587*green + 0.114*blue);
        }
    }
    return gray;
}

Image grayscale_to_rgb(const Image& img)
{
    assert(img.channels == 1);
    Image rgb(img.width, img.height, 3);
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < img.width; x++) {
        for (int y = 0; y < img.height; y++) {
            float gray_val = img.get_pixel(x, y, 0);
            rgb.set_pixel(x, y, 0, gray_val);
            rgb.set_pixel(x, y, 1, gray_val);
            rgb.set_pixel(x, y, 2, gray_val);
        }
    }
    return rgb;
}

// separable 2D gaussian blur for 1 channel image
Image gaussian_blur(const Image& img, float sigma)
{
    assert(img.channels == 1);

    int size = std::ceil(6 * sigma);
    if (size % 2 == 0)
        size++;
    int center = size / 2;
    Image kernel(size, 1, 1);
    float sum = 0;
    #pragma omp parallel for
    for (int k = -size/2; k <= size/2; k++) {
        float val = std::exp(-(k*k) / (2*sigma*sigma));
        kernel.set_pixel(center+k, 0, 0, val);
        #pragma omp critical
        sum += val;
    }
    //#pragma omp parallel for
    for (int k = 0; k < size; k++)
        kernel.data[k] /= sum;

    Image tmp(img.width, img.height, 1);
    Image filtered(img.width, img.height, 1);

    // convolve vertical
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < img.width; x++) {
        for (int y = 0; y < img.height; y++) {
            float sum = 0;
            for (int k = 0; k < size; k++) {
                int dy = -center + k;
                sum += img.get_pixel(x, y+dy, 0) * kernel.data[k];
            }
            tmp.set_pixel(x, y, 0, sum);
        }
    }
    // convolve horizontal
    #pragma omp parallel for collapse(2)
    for (int x = 0; x < img.width; x++) {
        for (int y = 0; y < img.height; y++) {
            float sum = 0;
            for (int k = 0; k < size; k++) {
                int dx = -center + k;
                sum += tmp.get_pixel(x+dx, y, 0) * kernel.data[k];
            }
            filtered.set_pixel(x, y, 0, sum);
        }
    }
    return filtered;
}
/*
float * gaussian_blur_by_data(float *data,int width, int height, float sigma)
{
    //assert(img.channels == 1);

    int size = std::ceil(6 * sigma);
    if (size % 2 == 0)
        size++;
    int center = size / 2;
    float kernel[size*1*1];
    float sum = 0;
    for (int k = -size/2; k <= size/2; k++) {
        float val = std::exp(-(k*k) / (2*sigma*sigma));
        kernel[center+k]=val;
        sum += val;
    }
    for (int k = 0; k < size; k++)
        kernel[k] /= sum;

    float tmp[width* height* 1];
    float filtered[width * height * 1];

    // convolve vertical
    for (int x = 0; x < width; x++) {
        for (int y = 0; y < height; y++) {
            float sum = 0;
            for (int k = 0; k < size; k++) {
                int dy = -center + k;
                sum += data[0*width*height + y*width + x] * kernel[k];
            }
            tmp[0*width*height + y*width + x] = sum;
        }
    }
    // convolve horizontal
    for (int x = 0; x < width; x++) {
        for (int y = 0; y < height; y++) {
            float sum = 0;
            for (int k = 0; k < size; k++) {
                int dx = -center + k;
                sum += tmp[0*width*height + y*width + x+dx] * kernel[k];
            }
            filtered[0*width*height + y*width + x]= sum;
        }
    }
    return filtered;
}
    */
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstring> // std::memcpy
#include <cstdlib> // malloc, free



// data: width*height floats (single channel)
// returns: malloc'ed buffer of width*height floats; caller must free()
float* gaussian_blur_by_data(const float* data, int width, int height, float sigma)
{
    if (sigma <= 0.0f) {
        // no blur: return a copy
        float* out = (float*)std::malloc(sizeof(float) * width * height);
        std::memcpy(out, data, sizeof(float) * width * height);
        return out;
    }

    // kernel size ~ 6*sigma, force odd and at least 3
    int size = static_cast<int>(std::ceil(6.0f * sigma));
    if (size < 3) size = 3;
    if ((size & 1) == 0) ++size;
    const int radius = size / 2;

    // build normalized 1D Gaussian kernel
    std::vector<float> kernel(size);
    float sumw = 0.0f;
    const float inv2sig2 = 1.0f / (2.0f * sigma * sigma);
    for (int k = -radius; k <= radius; ++k) {
        float w = std::exp(- (k * k) * inv2sig2);
        kernel[k + radius] = w;
        sumw += w;
    }
    for (float& w : kernel) w /= sumw;

    // temp and output buffers
    std::vector<float> tmp(width * height);
    float* out = (float*)std::malloc(sizeof(float) * width * height);

    // horizontal pass: data -> tmp
    for (int y = 0; y < height; ++y) {
        const int row = y * width;
        for (int x = 0; x < width; ++x) {
            float acc = 0.0f;
            for (int k = -radius; k <= radius; ++k) {
                int xx = clampi(x + k, 0, width - 1);
                acc += data[row + xx] * kernel[k + radius];
            }
            tmp[row + x] = acc;
        }
    }

    // vertical pass: tmp -> out
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            float acc = 0.0f;
            for (int k = -radius; k <= radius; ++k) {
                int yy = clampi(y + k, 0, height - 1);
                acc += tmp[yy * width + x] * kernel[k + radius];
            }
            out[y * width + x] = acc;
        }
    }

    return out; // caller: free(out)
}

void draw_point(Image& img, int x, int y, int size)
{
    #pragma omp parallel for collapse(2)
    for (int i = x-size/2; i <= x+size/2; i++) {
        for (int j = y-size/2; j <= y+size/2; j++) {
            if (i < 0 || i >= img.width) continue;
            if (j < 0 || j >= img.height) continue;
            if (std::abs(i-x) + std::abs(j-y) > size/2) continue;
            if (img.channels == 3) {
                img.set_pixel(i, j, 0, 1.f);
                img.set_pixel(i, j, 1, 0.f);
                img.set_pixel(i, j, 2, 0.f);
            } else {
                img.set_pixel(i, j, 0, 1.f);
            }
        }
    }
}

void draw_line(Image& img, int x1, int y1, int x2, int y2)
{
    if (x2 < x1) {
        std::swap(x1, x2);
        std::swap(y1, y2);
    }
    int dx = x2 - x1, dy = y2 - y1;
    #pragma omp parallel for
    for (int x = x1; x < x2; x++) {
        int y = y1 + dy*(x-x1)/dx;
        if (img.channels == 3) {
            img.set_pixel(x, y, 0, 0.f);
            img.set_pixel(x, y, 1, 1.f);
            img.set_pixel(x, y, 2, 0.f);
        } else {
            img.set_pixel(x, y, 0, 1.f);
        }
    }
}
Image gaussian_blur_twice(const Image& img, float sigma1, float sigma2)
{
    Image first = gaussian_blur(img, sigma1);
    return gaussian_blur(first, sigma2);
}
